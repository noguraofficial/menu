-- AlterTable
ALTER TABLE "public"."categories" ADD COLUMN     "priority" INTEGER NOT NULL DEFAULT 0;
