-- AlterTable
ALTER TABLE "public"."menu_items" ADD COLUMN     "priority" INTEGER NOT NULL DEFAULT 0;
