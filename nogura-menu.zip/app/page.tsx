import MenuSection from '@/components/MenuSection'

export default function Home() {
  return (
    <div className="min-h-screen">
      <MenuSection />
    </div>
  )
}
